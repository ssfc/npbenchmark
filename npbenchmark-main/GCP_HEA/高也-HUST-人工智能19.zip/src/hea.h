//
// Created by take_ on 2023/1/25.
//

#ifndef YUANFANG_REDUCE_HEA_H
#define YUANFANG_REDUCE_HEA_H

#include <algorithm>
#include <climits>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <iostream>
#include <fstream>
#include <random>
#include <vector>

using namespace std;


struct Move {
    int u;
    int vj;
};

class Population_solution {
public:
    vector<vector<int>> psol;
    vector<int> color_num;
    vector<unsigned int> index1s;
    vector<unsigned int> index2s;

    explicit Population_solution(int input_num_vertex, int input_num_color);
    ~Population_solution();
};

class Population {
public:
    int min_conflict; // the min conflict among the population collection;
    int min_conflict_index;
    vector<int> num_conflict;

    explicit Population(int input_num_population);
    ~Population();
};

// class HE;
class Hybrid_Evolution
{
private:
    long long int iter;

public:
    // variables;
    int num_vertex;
    int num_color;
    vector<vector<int>> adj_list; // adjacency list; dimension, (num_vertex+1) * (num_vertex+1);
    vector<int> vertex_edge_num; // number of edge of each vertex; dimension, num_vertex + 1;

    int conflict;
    int best_conflict;
    int conflict_num;
    vector<int> conflicts;
    vector<int> conflict_index;

    vector<vector<int>> adj_color_table;
    vector<vector<long long int>> tabu_tenure_table;

    Move moved;
    vector<Move> tabu_move;
    vector<Move> non_tabu_move;

    int min_delta; // 移动增量
    vector<Move> equal_nontabu_delta; //非禁忌相同delta值
    vector<Move> equal_tabu_delta; //禁忌相同delta值

    long long int max_iter;

    int num_population;
    vector<vector<unsigned int>> solution_collection;  // dim, num_population * (num_vertex+1)
    vector<Population_solution> population_solution;

    // debug variables:
    int max_equal_nontabu_count;
    int max_equal_tabu_count;
    double start_time;
    double end_time;

    // functions
    Hybrid_Evolution(int input_num_vertex, int input_num_color, int input_num_population, int input_seed);
    ~Hybrid_Evolution();

    void insert_adj_list(int i, int j);

    void find_move(vector<unsigned int> &solution);
    void make_move(vector<unsigned int> &solution);
    void tabu_search(vector<unsigned int> &solution, bool is_limit);

    void cross_over(unsigned int s1, unsigned int s2, vector<unsigned int> &index1);

    // debug function: compute conflict of a solution
    int compute_conflict(vector<unsigned int> &solution);
    [[nodiscard]] long long int get_iteration() const;
    void print_adj_list() const; // print adjacent list of graph;

    [[nodiscard]] int get_max_equal_nontabu_count() const;
    [[nodiscard]] int get_max_equal_tabu_count() const;
};


#endif //YUANFANG_REDUCE_HEA_H